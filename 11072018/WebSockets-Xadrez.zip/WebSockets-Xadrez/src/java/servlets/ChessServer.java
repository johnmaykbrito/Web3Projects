package servlets;

import java.io.IOException;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint("/chess")
public class ChessServer {

    private static Session white, black;

    @OnOpen
    public void onOpen(Session session) {
        System.out.println(session.getId() + " has opened a connection");
        try {
            if (white == null) {
                white = session;
            } else if (black == null) {
                black = session;
                white.getBasicRemote().sendText("{\"type\": 0, \"color\": 0, \"turn\": 0}");
                black.getBasicRemote().sendText("{\"type\": 0, \"color\": 1, \"turn\": 0}");
            } else {
                session.getBasicRemote().sendText("{\"type\": 2, \"message\": \"No more players allowed!\"}");
            }
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    @OnMessage
    public void onMessage(String message, Session session) {
        System.out.println("Message from " + session.getId() + ": " + message);
        try {
            if (session == white) {
                black.getBasicRemote().sendText(message);
            } else if (session == black) {
                white.getBasicRemote().sendText(message);
            } else {
                session.getBasicRemote().sendText("{\"type\": 2, \"message\": \"No more players allowed!\"}");
            }
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }

    @OnClose
    public void onClose(Session session) {
        System.out.println("Session " + session.getId() + " has ended");
        try {
            if (session == white) {
                black.getBasicRemote().sendText("{\"type\": 3}");
            } else {
                white.getBasicRemote().sendText("{\"type\": 3}");
            }
        } catch (IOException ex) {
            System.out.println(ex);
        }
    }
}
