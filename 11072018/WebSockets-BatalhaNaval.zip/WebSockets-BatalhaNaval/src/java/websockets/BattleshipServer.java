package websockets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.websocket.EncodeException;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;
import model.Grid;

@ServerEndpoint(value = "/battleship", encoders = BattleshipMessageEncoder.class, decoders = BattleshipMessageDecoder.class)
public class BattleshipServer {

    private static final List<Sala> salas = new ArrayList();
    private static final List<Session> jogadores = new ArrayList();

    static {
        for (int i = 0; i < 12; i++) {
            Sala s = new Sala();
            salas.add(s);
        }
    }

    @OnOpen
    public void onOpen(Session session) {
        System.out.println("onOpen");
        try {
            jogadores.add(session);
            this.sendTables();
        } catch (EncodeException | IOException ex) {
            System.out.println(ex);
        }
    }

    private void sendTables() throws EncodeException, IOException {
        BattleshipMessage obj = new BattleshipMessage();
        obj.setType(BattleshipMessage.RECEIVE_TABLES);
        obj.setSalas(salas);
        for (Session s : jogadores) {
            s.getBasicRemote().sendObject(obj);
        }
    }

    private void sendToVisitors(Sala s, BattleshipMessage message) {
        try {
            for (Session v : s.getsVisitors()) {
                message.setMyGrid(s.getgWhite().toString());
                message.setEnemyGrid(s.getgBlack().toString());
                v.getBasicRemote().sendObject(message);
            }
        } catch (EncodeException | IOException ex) {
            System.out.println(ex);
        }
    }

    private void sendShipsPositions(Session session, BattleshipMessage message) throws EncodeException, IOException {
        BattleshipMessage obj = new BattleshipMessage();
        Sala s = salas.get(message.getTurn());
        obj.setType(BattleshipMessage.RECEIVE_SHIPS_POSITIONS);
        //obj.setColor(message.getColor());
        Grid g;
        switch (message.getColor()) {
            case 0:
                g = new Grid(10, 10);
                obj.setMyGrid(g.toString());
                s.setsWhite(session);
                s.setgWhite(g);
                obj.setColor(0);
                session.getBasicRemote().sendObject(obj);
                this.sendToVisitors(s, obj);
                break;
            case 1:
                g = new Grid(10, 10);
                obj.setMyGrid(g.toString());
                s.setsBlack(session);
                s.setgBlack(g);
                obj.setColor(1);
                session.getBasicRemote().sendObject(obj);
                this.sendToVisitors(s, obj);
                break;
            case 2:
                s.getsVisitors().add(session);
                if (s.getgWhite() != null) {
                    obj.setMyGrid(s.getgWhite().toString());
                }
                if (s.getgBlack() != null) {
                    obj.setEnemyGrid(s.getgBlack().toString());
                }
                obj.setColor(2);
                session.getBasicRemote().sendObject(obj);
                break;
        }
        if (s.salaCheia()) {
            obj = new BattleshipMessage();
            obj.setType(BattleshipMessage.START_GAME);
            obj.setTurn(0);
            s.getsWhite().getBasicRemote().sendObject(obj);
            s.getsBlack().getBasicRemote().sendObject(obj);
            this.sendToVisitors(s, obj);
        }
    }

    private Sala searchRoom(Session session) {
        for (Sala s : salas) {
            if (s.getsWhite() == session || s.getsBlack() == session) {
                return s;
            }
            if (s.getsVisitors().contains(session)) {
                return s;
            }
        }
        return null;
    }

    private void receiveShot(Session session, BattleshipMessage message) throws EncodeException, IOException {
        Sala s = this.searchRoom(session);
        Session sPlayer, sEnemy;
        Grid gPlayer, gEnemy;
        int playerColor;
        if (session == s.getsWhite()) {
            gPlayer = s.getgWhite();
            gEnemy = s.getgBlack();
            sPlayer = s.getsWhite();
            sEnemy = s.getsBlack();
            playerColor = 0;
        } else {
            gPlayer = s.getgBlack();
            gEnemy = s.getgWhite();
            sPlayer = s.getsBlack();
            sEnemy = s.getsWhite();
            playerColor = 1;
        }
        boolean hit = gEnemy.setShot(message.getRow(), message.getCol());
        message.setType(BattleshipMessage.RECEIVE_SHOT);
        if (hit) {
            message.setTurn(playerColor);
        } else {
            message.setTurn((playerColor + 1) % 2);
        }

        message.setMyGrid(null);
        message.setEnemyGrid(gEnemy.codifiedGrid());
        sPlayer.getBasicRemote().sendObject(message);

        message.setMyGrid(gEnemy.toString());
        message.setEnemyGrid(null);
        sEnemy.getBasicRemote().sendObject(message);

        message.setMyGrid(gPlayer.toString());
        message.setEnemyGrid(gEnemy.toString());
        this.sendToVisitors(s, message);

        if (gEnemy.endOfGame()) {
            this.sairJogo(session, playerColor);
        }
    }

    @OnMessage
    public void onMessage(Session session, BattleshipMessage message) {
        System.out.println("onMessage");
        try {
            switch (message.getType()) {
                case BattleshipMessage.RECEIVE_TABLES:
                    this.sendTables();
                    break;
                case BattleshipMessage.RECEIVE_SHIPS_POSITIONS:
                    this.sendShipsPositions(session, message);
                    this.sendTables();
                    break;
                case BattleshipMessage.RECEIVE_SHOT:
                    this.receiveShot(session, message);
                    break;
                case BattleshipMessage.END_GAME:
                    this.sairJogo(session, 2);
                    break;
            }
        } catch (IOException | EncodeException ex) {
            System.out.println(ex);
        }
    }

    private void sairJogo(Session session, int winner) {
        try {
            Sala s = this.searchRoom(session);
            if (s != null) {
                BattleshipMessage message = new BattleshipMessage();
                message.setType(BattleshipMessage.END_GAME);
                message.setTurn(winner);
                session.getBasicRemote().sendObject(message);
                if (s.getsWhite() == session) {
                    if (s.getsBlack() != null) {
                        s.getsBlack().getBasicRemote().sendObject(message);
                    }
                    for (Session v : s.getsVisitors()) {
                        v.getBasicRemote().sendObject(message);
                    }
                    s.clean();
                } else if (s.getsBlack() == session) {
                    if (s.getsWhite() != null) {
                        s.getsWhite().getBasicRemote().sendObject(message);
                    }
                    for (Session v : s.getsVisitors()) {
                        v.getBasicRemote().sendObject(message);
                    }
                    s.clean();
                } else {
                    s.getsVisitors().remove(session);
                }
            }
        } catch (IOException | EncodeException ex) {
            System.out.println(ex);
        }
    }

    @OnClose
    public void onClose(Session session) {
        System.out.println("onClose");
        this.sairJogo(session, 2);
        jogadores.remove(session);
    }
}
