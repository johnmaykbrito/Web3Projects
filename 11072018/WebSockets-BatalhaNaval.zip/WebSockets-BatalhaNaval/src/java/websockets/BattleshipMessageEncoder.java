package websockets;

import java.util.List;
import javax.websocket.EncodeException;
import javax.websocket.Encoder;
import javax.websocket.EndpointConfig;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class BattleshipMessageEncoder implements Encoder.Text<BattleshipMessage> {

    @Override
    public void init(final EndpointConfig config) {
    }

    @Override
    public void destroy() {
    }

    @Override
    public String encode(final BattleshipMessage message) throws EncodeException {
//        return Json.createObjectBuilder()
//                .add("type", message.getType())
//                .add("color", message.getColor())
//                .add("turn", message.getTurn())
//                .add("row", message.getRow())
//                .add("col", message.getCol())
//                .add("grid", message.getGrid().toString()).build()
//                .toString();
        List<Sala> salao = message.getSalas();
        JSONArray array = new JSONArray();
        JSONObject obj = new JSONObject();
        try {
            if (salao != null) {
                for (int i = 0, size = salao.size(); i < size; i++) {
                    Sala s = salao.get(i);
                    JSONObject obj2 = new JSONObject();
                    obj2.put("table", i);
                    obj2.put("white", s.getsWhite() != null);
                    obj2.put("black", s.getsBlack() != null);
                    array.put(obj2);
                }
            }
            obj = obj
                    .put("type", message.getType())
                    .put("color", message.getColor())
                    .put("turn", message.getTurn())
                    .put("row", message.getRow())
                    .put("col", message.getCol())
                    .put("enemyGrid", message.getEnemyGrid())
                    .put("myGrid", message.getMyGrid())
                    .put("salas", array);
        } catch (JSONException e) {
            System.out.println(e);
        }
        return obj.toString();
    }
}
