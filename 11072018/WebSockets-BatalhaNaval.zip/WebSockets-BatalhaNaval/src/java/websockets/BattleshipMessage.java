package websockets;

import java.util.List;

public class BattleshipMessage {
    public static final int RECEIVE_TABLES = 0;
    public static final int RECEIVE_SHIPS_POSITIONS = 1;
    public static final int START_GAME = 2;
    public static final int RECEIVE_SHOT = 3;
    public static final int END_GAME = 4;

    /* Tipo da mensagem: 0 = primeiro jogador entrou, 1 = segundo jogador entrou */
    private int type = -1;
    private int row = -1;
    private int col = -1;
    /* Color of the player: 0 = primeiro jogador, 1 = segundo jogador, 2 = visitantes */
    private int color = -1;
    private int turn = -1;
    private String myGrid = null;
    private String enemyGrid = null;
    private List<Sala> salas = null;

    public List<Sala> getSalas() {
        return salas;
    }

    public void setSalas(List<Sala> salas) {
        this.salas = salas;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getCol() {
        return col;
    }

    public void setCol(int col) {
        this.col = col;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public int getTurn() {
        return turn;
    }

    public void setTurn(int turn) {
        this.turn = turn;
    }

    public String getMyGrid() {
        return myGrid;
    }

    public void setMyGrid(String myGrid) {
        this.myGrid = myGrid;
    }

    public String getEnemyGrid() {
        return enemyGrid;
    }

    public void setEnemyGrid(String enemyGrid) {
        this.enemyGrid = enemyGrid;
    }    
}
