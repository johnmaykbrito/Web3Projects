package websockets;

import javax.websocket.DecodeException;
import javax.websocket.Decoder;
import javax.websocket.EndpointConfig;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author paulo
 */
public class BattleshipMessageDecoder implements Decoder.Text<BattleshipMessage> {

    @Override
    public void init(final EndpointConfig config) {
    }

    @Override
    public void destroy() {
    }

    @Override
    public BattleshipMessage decode(final String textMessage) throws DecodeException {
        BattleshipMessage message = new BattleshipMessage();
        try {
            JSONObject obj = new JSONObject(textMessage);
            message.setType(obj.getInt("type"));
            message.setColor(obj.getInt("color"));
            message.setTurn(obj.getInt("turn"));
            message.setRow(obj.getInt("row"));
            message.setCol(obj.getInt("col"));
            message.setMyGrid(null);
            message.setEnemyGrid(null);
            message.setSalas(null);
        } catch (JSONException e) {
            System.out.println(e);
        }
        return message;
    }

    @Override
    public boolean willDecode(final String s) {
        return true;
    }
}
