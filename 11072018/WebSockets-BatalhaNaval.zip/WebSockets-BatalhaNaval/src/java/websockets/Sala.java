package websockets;

import java.util.ArrayList;
import java.util.List;
import javax.websocket.Session;
import model.Grid;

public class Sala {
    private Session sWhite, sBlack;
    private List<Session> sVisitors = new ArrayList();
    private Grid gWhite, gBlack;

    public Session getsWhite() {
        return sWhite;
    }

    public void setsWhite(Session sWhite) {
        this.sWhite = sWhite;
    }

    public Session getsBlack() {
        return sBlack;
    }

    public void setsBlack(Session sBlack) {
        this.sBlack = sBlack;
    }

    public Grid getgWhite() {
        return gWhite;
    }

    public void setgWhite(Grid gWhite) {
        this.gWhite = gWhite;
    }

    public Grid getgBlack() {
        return gBlack;
    }

    public void setgBlack(Grid gBlack) {
        this.gBlack = gBlack;
    }

    public List<Session> getsVisitors() {
        return sVisitors;
    }

    public void setsVisitors(List<Session> sVisitors) {
        this.sVisitors = sVisitors;
    }        
    
    public boolean salaCheia() {
        return this.sWhite != null && this.sBlack != null;
    }
    
    public void clean() {
        this.sWhite = null;
        this.sBlack = null;
        this.gWhite = null;
        this.gBlack = null;
        this.sVisitors.clear();
    }
}
