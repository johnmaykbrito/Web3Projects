package model;

public enum State {

    NONE(0), SHIP(1), WATER(2), SHOT(3);

    private final int valor;

    State(int valor) {
        this.valor = valor;
    }

    public int getValor() {
        return valor;
    }
}
