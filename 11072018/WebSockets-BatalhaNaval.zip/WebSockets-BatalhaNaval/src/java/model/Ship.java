package model;

public class Ship {

    private Point[] points = null;
    private int index = 0;

    public Ship(int size) {
        this.points = new Point[size];
    }

    public int getSize() {
        return this.points.length;
    }

    public void addPoint(int x, int y) {
        this.points[index++] = new Point(x, y);
    }

    public Point[] getPoints() {
        return points;
    }   
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[");
        for(Point p : this.points) {
            sb.append("(");
            sb.append(p.getX());
            sb.append(",");
            sb.append(p.getY());
            sb.append(")");
        }
        sb.append("]");
        return sb.toString();
    }
    
    public static void main(String[] args) {
        Ship s = new Ship(3);
        s.addPoint(3, 4);
        s.addPoint(3, 5);
        s.addPoint(3, 6);
        System.out.println(s);
    }
}
