package model;

import static model.State.NONE;

public class Cell {
    private State ship = NONE;
    
    public State getShip() {
        return ship;
    }
    
    public void setShip(State ship) {
        this.ship = ship;
    }

    @Override
    public String toString() {
        return "" + ship;
    }        
}
