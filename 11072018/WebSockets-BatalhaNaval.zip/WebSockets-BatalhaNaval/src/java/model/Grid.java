package model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import static model.State.NONE;
import static model.State.SHIP;
import static model.State.SHOT;
import static model.State.WATER;

public class Grid {

    private Cell[][] matrix = null;
    private final int rowsCount;
    private final int colsCount;
    private final List<Ship> ships = new ArrayList();

    public Grid(int[][] grid) {
        this.rowsCount = grid.length;
        this.colsCount = grid[0].length;
        this.matrix = this.createMatrix(grid);
        this.createShips();
    }

    public Grid(int rows, int cols) {
        this.rowsCount = rows;
        this.colsCount = cols;
        this.matrix = new Cell[rows][cols];
        this.createShips();

        this.fillCells();
        this.placeAllShips();
    }

    private void createShips() {
        int[] barcos = new int[]{4, 3, 3, 2, 2, 2, 1, 1, 1, 1};
        for (int i = 0; i < barcos.length; i++) {
            this.ships.add(new Ship(barcos[i]));
        }
    }

    private void placeAllShips() {
        int dir = 0;
        int xCoord = 0;
        int yCoord = 0;
        boolean flag;
        boolean overlap;
        for (Ship ship : this.ships) {
            flag = true;
            int shipSize = ship.getSize();
            while (flag) {
                overlap = false;
                xCoord = this.randInt(0, this.rowsCount - 1); //get a random x coordinate
                yCoord = this.randInt(0, this.colsCount - 1); //get a random y coordinate                
                dir = this.randInt(0, 1); //get a random direction, 0 = horizontal, 1 = vertical
                if ((matrix[xCoord][yCoord].getShip() == NONE) && (((dir == 0) && ((xCoord + shipSize) < this.rowsCount)) || ((dir == 1) && ((yCoord + shipSize) < this.colsCount)))) {
                    for (int j = 0; j < shipSize; j++) {
                        if ((dir == 0) && testCellPosition(xCoord + j, yCoord)) {
                            overlap = true;
                        } else if ((dir == 1) && testCellPosition(xCoord, yCoord + j)) {
                            overlap = true;
                        }
                    }
                    if (overlap == false) {
                        flag = false;
                    }
                }
            }
            for (int k = 0; k < shipSize; k++) {
                if (dir == 0) {
                    matrix[xCoord + k][yCoord].setShip(SHIP);
                    ship.addPoint(xCoord + k, yCoord);
                } else {
                    matrix[xCoord][yCoord + k].setShip(SHIP);
                    ship.addPoint(xCoord, yCoord + k);
                }
            }
        }
    }

    /**
     * Returns a pseudo-random number between min and max, inclusive. The
     * difference between min and max can be at most
     * <code>Integer.MAX_VALUE - 1</code>.
     *
     * @param min Minimim value
     * @param max Maximim value. Must be greater than min.
     * @return Integer between min and max, inclusive.
     * @see java.util.Random#nextInt(int)
     */
    private int randInt(int min, int max) {
        // Usually this can be a field rather than a method variable
        Random rand = new Random();

        // nextInt is normally exclusive of the top value,
        // so add 1 to make it inclusive
        int randomNum = rand.nextInt((max - min) + 1) + min;

        return randomNum;
    }

    private boolean testCellPosition(int x, int y) {
        return testCell(x - 1, y - 1) || testCell(x - 1, y) || testCell(x - 1, y + 1)
                || testCell(x, y - 1) || testCell(x, y) || testCell(x, y + 1)
                || testCell(x + 1, y - 1) || testCell(x + 1, y) || testCell(x + 1, y + 1);
    }

    private boolean testCell(int x, int y) {
        if (x >= 0 && x < this.rowsCount && y >= 0 && y < this.colsCount) {
            return matrix[x][y].getShip() == SHIP;
        } else {
            return false;
        }
    }

    private boolean testDestroyedShip(Ship ship) {
        boolean ok = true;
        for (Point p : ship.getPoints()) {
            if (this.matrix[p.getX()][p.getY()].getShip() == SHIP) {
                ok = false;
            }
        }
        return ok;
    }

    private void shootHV(Point p) {
        int row = p.getX();
        int col = p.getY();
        if (row - 1 >= 0) {
            if (this.matrix[row - 1][col].getShip() == NONE) {
                this.matrix[row - 1][col].setShip(WATER);
            }
        }
        if (col - 1 >= 0)  {
            if (this.matrix[row][col - 1].getShip() == NONE) {
                this.matrix[row][col - 1].setShip(WATER);
            }
        }
        if (col + 1 < this.colsCount) {
            if (this.matrix[row][col + 1].getShip() == NONE) {
                this.matrix[row][col + 1].setShip(WATER);
            }
        }
        if (row + 1 < this.rowsCount) {
            if (this.matrix[row + 1][col].getShip() == NONE) {
                this.matrix[row + 1][col].setShip(WATER);
            }
        }
    }

    private void fillUnuseful() {
        for (Ship ship : this.ships) {
            if (testDestroyedShip(ship)) {
                for (Point p : ship.getPoints()) {
                    shootHV(p);
                }
            }
        }
    }

    private void fillCells() {
        for (int i = 0; i < this.rowsCount; i++) {
            for (int j = 0; j < this.colsCount; j++) {
                this.matrix[i][j] = new Cell();
            }
        }
    }

    public void print() {
        for (int i = 0; i < this.rowsCount; i++) {
            System.out.println(Arrays.toString(this.matrix[i]));
        }
    }

    public void printShips() {
        for (Ship ship : this.ships) {
            System.out.println(ship);
        }
    }

    public boolean endOfGame() {
        boolean fim = true;
        for (int i = 0; i < this.rowsCount; i++) {
            for (int j = 0; j < this.colsCount; j++) {
                if (this.matrix[i][j].getShip() == SHIP) {
                    fim = false;
                }
            }
        }
        return fim;
    }

    public boolean setShot(int row, int col) {
        State state = this.matrix[row][col].getShip();
        boolean hit = false;
        switch (state) {
            case WATER:
            case NONE:
                this.matrix[row][col].setShip(WATER);
                break;
            case SHIP:
            case SHOT:
                hit = true;
                this.matrix[row][col].setShip(SHOT);
                this.shootDiagonals(row, col);
                this.fillUnuseful();
                break;
        }
        return hit;
    }

    private void shootDiagonals(int row, int col) {
        if (row - 1 >= 0 && col - 1 >= 0) {
            this.matrix[row - 1][col - 1].setShip(WATER);
        }
        if (row - 1 >= 0 && col + 1 < this.colsCount) {
            this.matrix[row - 1][col + 1].setShip(WATER);
        }
        if (row + 1 < this.rowsCount && col - 1 >= 0) {
            this.matrix[row + 1][col - 1].setShip(WATER);
        }
        if (row + 1 < this.rowsCount && col + 1 < this.colsCount) {
            this.matrix[row + 1][col + 1].setShip(WATER);
        }
    }

    public String codifiedGrid() {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < this.rowsCount; i++) {
            sb.append("[");
            for (int j = 0; j < this.colsCount; j++) {
                int state = this.matrix[i][j].getShip().getValor();
                if (state == 1) {
                    sb.append(0);
                } else {
                    sb.append(state);
                }
                if (j != this.colsCount - 1) {
                    sb.append(",");
                }
            }
            if (i != this.rowsCount - 1) {
                sb.append("],");
            }
        }
        sb.append("]]");
        return sb.toString();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < this.rowsCount; i++) {
            sb.append("[");
            for (int j = 0; j < this.colsCount; j++) {
                sb.append(this.matrix[i][j].getShip().getValor());
                if (j != this.colsCount - 1) {
                    sb.append(",");
                }
            }
            if (i != this.rowsCount - 1) {
                sb.append("],");
            }
        }
        sb.append("]]");
        return sb.toString();
    }

    private Cell[][] createMatrix(int[][] grid) {
        Cell[][] m = new Cell[this.rowsCount][this.colsCount];
        for (int i = 0; i < this.rowsCount; i++) {
            for (int j = 0; j < this.colsCount; j++) {
                Cell c = new Cell();
                switch (grid[i][j]) {
                    case 0:
                        c.setShip(NONE);
                        break;
                    case 1:
                        c.setShip(SHIP);
                        break;
                    case 2:
                        c.setShip(WATER);
                        break;
                    case 3:
                        c.setShip(SHOT);
                        break;
                }
                m[i][j] = c;
            }
        }
        return m;
    }

    public static void main(String[] args) {
        Grid t = new Grid(10, 10);
//        int[][] matrix = new int[][]{{0, 0, 0, 0, 0, 1, 0, 0, 0, 1}, {0, 0, 0, 0, 0, 1, 0, 0, 0, 1}, {0, 0, 0, 1, 0, 1, 0, 0, 0, 1}, {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}, {1, 1, 0, 0, 0, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 1, 0, 0, 0, 1}, {0, 0, 1, 0, 0, 0, 0, 1, 0, 1}, {0, 0, 0, 0, 0, 0, 0, 1, 0, 0}, {0, 1, 1, 1, 1, 0, 0, 0, 0, 0}, {0, 0, 0, 0, 0, 0, 1, 0, 0, 0}};
//        Grid t = new Grid(matrix);
        System.out.println(t.toString());
        t.setShot(1, 6);
        t.setShot(2, 3);
        t.setShot(4, 7);
        t.setShot(0, 8);
        System.out.println(t.toString());
        System.out.println(t.codifiedGrid());
//        System.out.println(t.toString());
//        t.printShips();
    }
}
