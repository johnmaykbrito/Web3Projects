function BatalhaNaval(conn) {
    this.minhaMatriz = document.querySelector("table:first-child");
    this.outraMatriz = document.querySelector("table + table");
    this.cor = null;
    var connShots = conn;
    this.printMatrix = function (matrix, type) {
        var m = (type) ? this.minhaMatriz : this.outraMatriz;
        var rowSize = m.rows.length, colSize = m.rows[0].cells.length;
        for (var i = 1; i < rowSize; i++) {
            for (var j = 1; j < colSize; j++) {
                switch (matrix[i - 1][j - 1]) {
                    case 0:
                        m.rows[i].cells[j].className = "none";
                        break;
                    case 1:
                        m.rows[i].cells[j].className = "ship";
                        break;
                    case 2:
                        m.rows[i].cells[j].className = "water";
                        break;
                    case 3:
                        m.rows[i].cells[j].className = "shot";
                        break;
                }
            }
        }
    };
    this.shot = function () {
        var colIndex = this.cellIndex - 1;
        var rowIndex = this.parentNode.rowIndex - 1;
        var msg = {type: 3, color: -1, turn: -1, row: rowIndex, col: colIndex};
        connShots.ws.send(JSON.stringify(msg));
    };
    this.clearMatrix = function () {
        var cells = this.outraMatriz.querySelectorAll("td");
        Array.prototype.forEach.call(cells, function (element) {
            element.className = "none";
        });
    };
    this.setEvents = function (element) {
        if (element.className === "none" && this.cor !== 2) {
            element.addEventListener("click", this.shot);
        }
    };
    this.unsetEvents = function (element) {
        element.removeEventListener("click", this.shot);
    };
    this.turnMessage = function (corDaVez) {
        switch(this.cor) {
            case 0:
                if(corDaVez === 0) {
                    this.minhaMatriz.className = "unsel";
                    this.outraMatriz.className = "sel";
                } else {
                    this.minhaMatriz.className = "sel";
                    this.outraMatriz.className = "unsel";
                }
                break;
            case 1:
            case 2:
                if(corDaVez === 0) {
                    this.minhaMatriz.className = "sel";
                    this.outraMatriz.className = "unsel";
                } else {
                    this.minhaMatriz.className = "unsel";
                    this.outraMatriz.className = "sel";
                }
                break;
        }
        var cells = this.outraMatriz.querySelectorAll("td");
        if (this.cor === corDaVez) {
            Array.prototype.forEach.call(cells, this.setEvents, this);
        } else {
            Array.prototype.forEach.call(cells, this.unsetEvents, this);
        }
    };
    this.writeResponse = function (text) {
        var messages = document.getElementById("results");
        messages.innerHTML = text;
    };
}
