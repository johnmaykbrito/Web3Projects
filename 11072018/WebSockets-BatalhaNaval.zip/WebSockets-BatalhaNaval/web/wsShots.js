var salao;
function Connection() {
    this.ws = null;
    var _self = this;
    this.bn = new BatalhaNaval(this);
    this.onOpen = function () {
        console.log("onOpen");
        _self.bn.writeResponse("");
    };
    this.onMessage = function (evt) {
        console.log("onMessage: " + evt.data);
        var data = JSON.parse(evt.data);
        if (data.type === 0) {
            salao.printSalas(data.salas);
        } else if (data.type === 1) {
            /* Receiving the ships position from the server */
            _self.bn.cor = data.color;
            if (data.myGrid) {
                _self.bn.printMatrix(JSON.parse(data.myGrid), true);
            }
            if (data.enemyGrid) {
                _self.bn.printMatrix(JSON.parse(data.enemyGrid), false);
            }
            if (data.myGrid === undefined || data.enemyGrid === undefined) {
                _self.bn.clearMatrix();
            }
        } else if (data.type === 2) {
            /* Starting the game. Informing which player must start */
            _self.bn.turnMessage(data.turn);
        } else if (data.type === 3) {
            /* Receiving a shot. Printing an X or a bullet */
            if (data.myGrid) {
                _self.bn.printMatrix(JSON.parse(data.myGrid), true);
            }
            if (data.enemyGrid) {
                _self.bn.printMatrix(JSON.parse(data.enemyGrid), false);
            }
            if (data.myGrid === undefined || data.enemyGrid === undefined) {
                _self.bn.turnMessage(data.turn);
            }
        } else if (data.type === 4) {
            /* End of the game */
            if (_self.bn.cor === 2 || data.turn === 2) {
                _self.bn.writeResponse("End of the game!");
            } else {
                if (data.turn === _self.bn.cor) {
                    _self.bn.writeResponse("You won the game!");
                } else {
                    _self.bn.writeResponse("You lost the game!");
                }
            }
        } else {
            /* Error in the application */
            _self.bn.writeResponse(data.message);
        }
    };
    this.onClose = function () {
        console.log("Connection closed.");
    };
    this.onError = function (evt) {
        _self.bn.writeResponse("error: " + evt.data);
    };
    this.openConnection = function () {
        var wsUri = "ws://" + document.location.host + document.location.pathname + "battleship";
        if (this.ws === null) {
            this.ws = new WebSocket(wsUri);
            this.ws.binaryType = "arraybuffer";
            this.ws.onopen = this.onOpen;
            this.ws.onmessage = this.onMessage;
            this.ws.onerror = this.onError;
            this.ws.onclose = this.onClose;
        }
    };
}