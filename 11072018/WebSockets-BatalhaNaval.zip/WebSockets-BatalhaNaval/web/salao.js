function Salao() {
    var _self = this;
    var connShots = null;
    this.showSala = function (show, params) {
        var salao = document.getElementById("salao");
        var sala = document.getElementById("sala");
        if (show === true) {
            /* Entrando em uma sala */
            salao.className = "hide";
            sala.className = "show";
            var msg = {type: 1, color: params[0], turn: params[1], row: -1, col: -1};
            connShots.ws.send(JSON.stringify(msg));
        } else if (show === false) {
            /* Comecando o jogo */
            salao.className = "show";
            sala.className = "hide";
        } else {
            /* Pressionou no botao de voltar ao Salao */
            salao.className = "show";
            sala.className = "hide";
            var msg = {type: 0, color: -1, turn: -1, row: -1, col: -1};
            connShots.ws.send(JSON.stringify(msg));
            msg = {type: 4, color: -1, turn: -1, row: -1, col: -1};
            connShots.ws.send(JSON.stringify(msg));            
        }
    };
    this.jogar = function () {
        _self.showSala(true, [this.jogador, this.mesa]);
        connShots.bn.writeResponse("");
    };
    this.setVerEvents = function (elem, index) {
        elem.addEventListener("click", this.jogar);
        elem.mesa = index;
        elem.jogador = 2;
    };
    this.setPlayEvents = function (elem, index) {
        elem.addEventListener("click", this.jogar);
        elem.mesa = Math.floor(index / 2);
        elem.jogador = parseInt(elem.value);
    };
    this.printSalas = function (salas) {
        var buttons = document.querySelectorAll("button");
        Array.prototype.forEach.call(buttons, this.setPlayEvents, this);
        var inputs = document.querySelectorAll("input[value=Ver]");
        Array.prototype.forEach.call(inputs, this.setVerEvents, this);
        var botao = document.getElementById("voltar");
        botao.addEventListener("click", this.showSala);

        var fields = document.querySelectorAll("fieldset");
        for (var i = 0; i < fields.length; i++) {
            var field = fields[i];
            var buttons = field.querySelectorAll("button");
            if (!salas[i].white) {
                buttons[0].disabled = false;
            } else {
                buttons[0].disabled = true;
            }
            if (!salas[i].black) {
                buttons[1].disabled = false;
            } else {
                buttons[1].disabled = true;
            }
        }
    };
    this.init = function () {
        connShots = new Connection();
        connShots.openConnection();
    };
}
window.onload = function () {
    salao = new Salao();
    salao.showSala(false);
    salao.init();
};