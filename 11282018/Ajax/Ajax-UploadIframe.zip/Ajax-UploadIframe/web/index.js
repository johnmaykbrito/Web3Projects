function startUpload() {
    document.getElementById('f1_upload_process').style.visibility = 'visible';
    return true;
}

function stopUpload(success) {
    if (success === 1) {
        document.getElementById('result').innerHTML =
                '<span class="msg">The file was uploaded successfully!</span>';
    }
    else {
        document.getElementById('result').innerHTML =
                '<span class="emsg">There was an error during file upload!</span>';
    }
    document.getElementById('f1_upload_process').style.visibility = 'hidden';
    document.getElementById('f1_upload_form').reset();
    return true;
}

onload = function () {
    var form = document.forms[0];
    form.onsubmit = startUpload;
};