package servlets;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@MultipartConfig
public class Exemplo8 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private void inserirImagemDiretorio(Part item) throws IOException {

        // Pega o diretório /logo dentro do diretório atual de onde a
        // aplicação está rodando
        String caminho = getServletContext().getRealPath("/logo") + "/";

        // Cria o diretório caso ele não exista
        File diretorio = new File(caminho);
        if (!diretorio.exists()) {
            diretorio.mkdir();
        }

        // Mandar o arquivo para o diretório informado
        String nome = item.getSubmittedFileName();
//        String arq[] = nome.split("\\\\");
//        for (int i = 0; i < arq.length; i++) {
//            nome = arq[i];
//        }

        File file = new File(diretorio, nome);
        try (FileOutputStream output = new FileOutputStream(file)) {
            InputStream is = item.getInputStream();
            byte[] buffer = new byte[2048];
            int nLidos;
            while ((nLidos = is.read(buffer)) >= 0) {
                output.write(buffer, 0, nLidos);
            }
            
            output.flush();
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        Part filePart = req.getPart("myfile");
        int result = 0;
        if (filePart.getName().length() > 0) {
            this.inserirImagemDiretorio(filePart);
            result = 1;
        }
        resp.setContentType("text/html");
        resp.getWriter().write("<script type='text/javascript'>window.top.window.stopUpload(" + result + ");</script>");
    }
}
