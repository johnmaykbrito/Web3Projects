package servlets;

import basicas.Funcionario;
import cadastro.FachadaFuncionarios;
import java.io.File;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@MultipartConfig
public class Exemplo6b extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private void armazenarImagem(Part item) throws IOException {
        String caminho = getServletContext().getRealPath("/logo") + "/";

        // Cria o diretório caso ele não exista
        File diretorio = new File(caminho);
        if (!diretorio.exists()) {
            diretorio.mkdir();
        }
        String nome = item.getSubmittedFileName();
        item.write(caminho + nome);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String nome = req.getParameter("nome");
        String dataNascimento = req.getParameter("dataNascimento");
        String salario = req.getParameter("salario");
        Part imagem = req.getPart("imagem");
        String path = imagem.getSubmittedFileName();
        this.armazenarImagem(imagem);

        Funcionario func = new Funcionario(nome, salario, dataNascimento, path);
        FachadaFuncionarios fachada = FachadaFuncionarios.getInstance();
        fachada.inserir(func);
        req.getRequestDispatcher("Exemplo6a").forward(req, resp);
    }
}
