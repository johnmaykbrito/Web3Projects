function postWithParameters() {
	var xml = new XMLHttpRequest();
	xml.onreadystatechange = function () {
		if(xml.readyState == 4) {
			var mensagem = document.getElementById("message2");
			mensagem.innerHTML = xml.responseText;
		}
	};
	var text = document.getElementById("text");
	var params = "value=" + encodeURIComponent(text.value);
	xml.open("POST", "ServletAjaxWithParams", true);
	xml.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xml.setRequestHeader("Content-length", params.length);
	xml.send(params);
}

function getWithParameters() {
	var xml = new XMLHttpRequest();
	xml.onreadystatechange = function () {
		if(xml.readyState == 4) {
			var mensagem = document.getElementById("message2");
			mensagem.innerHTML = xml.responseText;
		}
	};
	var text = document.getElementById("text");
	xml.open("GET", "ServletAjaxWithParams?value=" + encodeURIComponent(text.value), true);
	xml.send(null);
}

function postWithoutParameters() {
	var xml = new XMLHttpRequest();
	xml.onreadystatechange = function () {
		if(xml.readyState == 4) {
			var mensagem = document.getElementById("message1");
			mensagem.innerHTML = xml.responseText;
		}
	};
	xml.open("POST", "ServletAjaxWithoutParams", true);
	xml.send(null);
}

function getWithoutParameters() {
	var xml = new XMLHttpRequest();
	xml.onreadystatechange = function () {
		if(xml.readyState == 4) {
			var mensagem = document.getElementById("message1");
			mensagem.innerHTML = xml.responseText;
		}
	};
	xml.open("GET", "ServletAjaxWithoutParams", true);
	xml.send(null);
}

function registerEvents() {
	var botao = document.getElementById("botaoGET1");
	botao.onclick = getWithoutParameters;	
	botao = document.getElementById("botaoPOST1");
	botao.onclick = postWithoutParameters;
	botao = document.getElementById("botaoGET2");
	botao.onclick = getWithParameters;
	botao = document.getElementById("botaoPOST2");
	botao.onclick = postWithParameters;
}

onload = registerEvents;