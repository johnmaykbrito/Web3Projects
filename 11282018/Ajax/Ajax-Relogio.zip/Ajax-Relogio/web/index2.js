function printDigits(tipo, numero) {
    var digitos = [[1,1,1,0,1,1,1],[0,0,1,0,0,1,0],[1,0,1,1,1,0,1],[1,0,1,1,0,1,1],[0,1,1,1,0,1,0],[1,1,0,1,0,1,1],[1,1,0,1,1,1,1],[1,0,1,0,0,1,0],[1,1,1,1,1,1,1],[1,1,1,1,0,1,1]];
    var clock = document.getElementById("dclock");
    var doc = clock.getSVGDocument();
    var barras = doc.getElementsByTagName("path");
    var decimal = parseInt(numero/10);
    var unidade = numero%10;
    for(var i = 0; i < 7; i++) {
        if(digitos[decimal][i] == 1) {
            barras[14*tipo+i].setAttribute("class", "ativo");
        }
        if(digitos[unidade][i] == 1) {
            barras[14*tipo+i+7].setAttribute("class", "ativo");
        }
    }
}
function cleanDigits() {
    var clock = document.getElementById("dclock");
    var doc = clock.getSVGDocument();
    var barras = doc.getElementsByTagName("path");
    for(var i = 0; i < barras.length-4; i++) {
        barras[i].setAttribute("class","");
    }
}
function mostraHoraDigital() {
    cleanDigits();
    var d = new Date("October 13, 1975 " + getTime());
    printDigits(0, d.getHours());
    printDigits(1, d.getMinutes());
    printDigits(2, d.getSeconds());
    setTimeout("mostraHoraDigital()", 1000);
}
