    function getTime() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("get","ServletHora", false);
    xmlhttp.send(null);
    return xmlhttp.responseText;
}
function mostraHoraPagina() {
    var d = new Date("October 13, 1975 " + getTime());
    var p = document.getElementById("raw");
    p.innerHTML = (d.getHours() < 10 ? "0" + d.getHours() : d.getHours()) + ":" + (d.getMinutes() < 10 ? "0" + d.getMinutes() : d.getMinutes()) + ":" + (d.getSeconds() < 10 ? "0" + d.getSeconds() : d.getSeconds());
    setTimeout("mostraHoraPagina()", 1000);
}
function selecionarRelogio() {
    var opcao = parseInt(this.value);
    var ps = document.getElementsByTagName("p");
    switch(opcao) {
        case 0:
            ps[0].style.display = "block";
            ps[1].style.display = "none";
            ps[2].style.display = "none";
            break;
        case 1:
            ps[0].style.display = "none";
            ps[1].style.display = "block";
            ps[2].style.display = "none";
            break;
        case 2:
            ps[0].style.display = "none";
            ps[1].style.display = "none";
            ps[2].style.display = "block";
            break;
    }
}
function init() {
    var form = document.forms[0];
    form.opcao.onchange = selecionarRelogio;
    mostraHoraPagina();
    mostraHoraDigital();
    mostraHoraAnalogica();
    var ps = document.getElementsByTagName("p");
    ps[1].style.display = "none";
    ps[2].style.display = "none";
}
onload = init;