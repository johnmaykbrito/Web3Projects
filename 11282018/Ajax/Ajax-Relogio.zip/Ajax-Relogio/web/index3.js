function mostraHoraAnalogica() {
    var clock = document.getElementById("aclock");
    var doc = clock.getSVGDocument();
    // Create new Date() object.
    var d = new Date("October 13, 1975 " + getTime());
    // Get current seconds.
    var s = d.getSeconds();
    // Get current minutes and add the current second.
    var m = d.getMinutes() + s / 60;
    // Get current hours and add the current minute.
    var h = d.getHours() + m / 60;
    // Rotate the second clockhand to the current seconds.
    doc.getElementById("Second").setAttribute("transform", "rotate(" + (s * 6) + ", 256, 256)");
    doc.getElementById("SecondShadow").setAttribute("transform", "rotate(" + (s * 6) + ", 253, 259)");
    // Rotate the minute clockhand to the current minute.
    doc.getElementById("Minute").setAttribute("transform", "rotate(" + (m * 6) + ", 256, 256)");
    doc.getElementById("MinuteShadow").setAttribute("transform", "rotate(" + (m * 6) + ", 254, 258)");
    // Rotate the hour clockhand to the current hour.
    doc.getElementById("Hour").setAttribute("transform", "rotate(" + (h * 30) + ", 256, 256)");
    doc.getElementById("HourShadow").setAttribute("transform", "rotate(" + (h * 30) + ", 255, 257)");
    setTimeout("mostraHoraAnalogica()", 1000);
}
