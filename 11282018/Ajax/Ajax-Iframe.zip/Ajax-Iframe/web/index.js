function mostrarDados() {
    var frame = document.getElementById("iframe");
    var resposta = document.getElementById("resposta");
    resposta.innerHTML = frame.contentDocument.body.innerHTML;
}
function iframe() {
    var nome = document.forms[0].nome.value;
    var frame = document.getElementById("iframe");
    frame.src = "MyServlet?par=" + nome;
    frame.onload = mostrarDados;
    return false;
}
function init() {
    var nome = document.forms[0].submeter;
    nome.onclick = iframe;
}
onload = init;