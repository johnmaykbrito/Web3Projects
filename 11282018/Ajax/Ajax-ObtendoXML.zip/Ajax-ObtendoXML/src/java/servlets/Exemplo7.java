package servlets;

import basicas.CD;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.json.JSONArray;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Exemplo7 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private String getElementContent(Element e, String elem) {
        return e.getElementsByTagName(elem).item(0).getFirstChild().getNodeValue();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(new File("/home/paulo/Dropbox/NetBeansProjects/Ajax-ObtendoXML/web/cd_catalog.xml"));
            NodeList cds = doc.getElementsByTagName("cd");
            List<CD> discos = new ArrayList<CD>();
            int size = cds.getLength();
            for (int i = 0; i < size; i++) {
                Element cd = (Element) cds.item(i);
                String title = this.getElementContent(cd, "title");
                String artist = this.getElementContent(cd, "artist");
                String year = this.getElementContent(cd, "year");
                String price = this.getElementContent(cd, "price");
                String country = this.getElementContent(cd, "country");
                String company = this.getElementContent(cd, "company");
                CD album = new CD(title, artist, country, company, Double.parseDouble(price), Integer.parseInt(year));
                discos.add(album);
            }
            JSONArray json = new JSONArray(discos);
            resp.setContentType("text/plain");
            resp.getWriter().write(json.toString());
        } catch (ParserConfigurationException pce) {
        } catch (SAXException sax) {
        }
    }
}
