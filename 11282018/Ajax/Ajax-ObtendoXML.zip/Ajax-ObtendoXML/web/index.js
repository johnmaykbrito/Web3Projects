function Catalog() {
    this.xml = new XMLHttpRequest();
    this.registerEvents = function () {
        this.xml.open("get", "cd_catalog.xml", true);
        this.xml.send(null);

        var cd = document.getElementById("titulo");
        cd.onkeyup = this.suggestXSLT.bind(this);
        var botao = document.getElementById("botaoObterTitulos");
        botao.onclick = this.getWithoutParameters.bind(this);
        var radios = document.forms[1].tipoano;
        for (var i = 0; i < radios.length; i++) {
            radios[i].onchange = this.getWithoutParameters.bind(this);
        }
        document.forms[1].ano.onkeypress = this.getWithoutParameters.bind(this);
        var form = document.forms[2];
        form.onsubmit = this.receberDados.bind(this);
    };
    this.getWithoutParameters = function () {
        var mensagem = document.getElementById("message1");
        var catalog = this.xml.responseXML;
        var cds = catalog.getElementsByTagName("cd");
        var ano = parseInt(document.forms[1].ano.value);
        var tipoano = document.forms[1].tipoano[0].checked;
        var saida = "<ul>";
        for (var i = 0; i < cds.length; i++) {
            var cd = cds[i];
            var year = parseInt(cd.getElementsByTagName("year").item(0).firstChild.nodeValue);
            if (isNaN(ano) || (tipoano === true && ano <= year) || (tipoano === false && ano > year)) {
                var price = cd.getElementsByTagName("price").item(0).firstChild.nodeValue;
                var estilo = (price > 10) ? "caro" : "barato";
                saida += "<li class=" + estilo + ">" + cd.getElementsByTagName("title").item(0).firstChild.nodeValue + " &mdash; " + year + " &mdash; " + price + "</li>";
            }
        }
        saida += "</ul>";
        mensagem.innerHTML = saida;
    };
    this.suggestDOM = function (event) {
        if (event.keyCode >= 37 && event.keyCode <= 40)
            return;
        var datalist = document.getElementById("titles");
        var catalog = this.xml.responseXML;
        var titles = catalog.getElementsByTagName("title");
        var titulo = document.forms[0].titulo.value;
        if (titulo.length > 0) {
            var saida = '';
            for (var i = 0; i < titles.length; i++) {
                var title = titles[i];
                var temp = title.firstChild.nodeValue;
                if (temp.substring(0, titulo.length).toLowerCase() === titulo.toLowerCase()) {
                    saida += "<option>" + temp + "</option>";
                }
            }
            saida += '';
            if (saida.length > 0) {
                datalist.innerHTML = saida;
            }
            else {
                datalist.innerHTML = "";
            }
        } else {
            datalist.innerHTML = "";
        }
    };
    this.loadXMLDoc = function (filename) {
        var xhttp = new XMLHttpRequest();
        xhttp.open("get", filename, false);
        xhttp.send(null);
        return xhttp.responseXML;
    };
    this.suggestXSLT = function (event) {
        var titulo = document.forms[0].titulo.value;
        if ((event.keyCode >= 37 && event.keyCode <= 40) || titulo.length === 0)
            return;
        var xsl = this.loadXMLDoc("datalist.xsl");
        var catalog = this.xml.responseXML;
        var xsltProcessor = Saxon.newXSLT20Processor();
        xsltProcessor.importStylesheet(xsl);
        xsltProcessor.setParameter(null, "nome", titulo);
        var resultDocument = xsltProcessor.transformToFragment(catalog, document);
        var titles = document.getElementById("titles");
        titles.innerHTML = "";
        titles.appendChild(resultDocument);
    };
    this.receberDados = function () {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4) {
                var s = xhr.responseText;
                document.getElementById("json").innerHTML = s;
                var func = JSON.parse(s);
                var mensagem = document.getElementById("retorno");
                var saida = "<table class='sortable'><thead><tr><th>Title</th><th>Artist</th><th>Country</th><th>Company</th><th>Price</th><th>Year</th></tr></thead><tbody>";
                for (var i = 0; i < func.length; i++) {
                    var cd = func[i];
                    saida += "<tr><td>" + cd.title + "</td><td>" + cd.artist
                            + "</td><td>" + cd.country + "</td><td>" + cd.company
                            + "</td><td>" + cd.price + "</td><td>" + cd.year
                            + "</td></tr>";
                }
                saida += "</tbody></table>";
                mensagem.innerHTML = saida;
                var table = document.getElementsByTagName("table")[0];
                sorttable.makeSortable(table);
            }
        };
        xhr.open("get", "Exemplo7", true);
        xhr.send(null);
        return false;
    };
}
onload = function () {
    var c = new Catalog();
    c.registerEvents();
};
